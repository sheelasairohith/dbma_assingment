package company;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class AddCompany extends Panel
{
	Button AddCompanyButton;
	TextField sidText, snameText, ratingText, addressText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public AddCompany() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();

	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","assingment","vasavi");
		  statement = connection.createStatement();
		  statement.executeUpdate("commit");

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI() 
	{		
		//Handle Insert Account Button
		AddCompanyButton = new Button("Add Company");
		AddCompanyButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  //String query = "INSERT INTO company (ID,NAME,Address,RATING) VALUES (2,'sai rohith','abc colony',20)";				  
				  String query= "INSERT INTO company VALUES(" + sidText.getText() + ", " + "'" + snameText.getText() + "','" + addressText.getText() + "'," + ratingText.getText() + ")";
				  int i = statement.executeUpdate(query);
				  statement.executeUpdate("commit");
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});
		sidText=new TextField(15);
		snameText = new TextField(15);
		ratingText = new TextField(15);
		addressText = new TextField(15);

		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Company ID:"));
		first.add(sidText);
		first.add(new Label("Name:"));
		first.add(snameText);
		first.add(new Label("Rating:"));
		first.add(ratingText);
		first.add(new Label("Address:"));
		first.add(addressText);
		first.setBounds(125,90,200,100);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(AddCompanyButton);
        second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		setLayout(null);

		add(first);
		add(second);
		add(third);
		setSize(500, 600);
		setVisible(true);
		System.out.println("hello");
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

}
