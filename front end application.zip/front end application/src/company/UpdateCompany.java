package company;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateCompany extends Panel 
{
	Button updateCompanyButton;
	List companyIDList;
	TextField sidText, snameText, ratingText, addressText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateCompany() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","assingment","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	public void loadCompanies() 
	{	   
		try 
		{
			companyIDList.removeAll();
		  rs = statement.executeQuery("SELECT ID FROM company");
		  while (rs.next()) 
		  {
			companyIDList.add(rs.getString("ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    companyIDList = new List(10);
		loadCompanies();
		add(companyIDList);
		
		companyIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM company where ID ="+companyIDList.getSelectedItem());
					rs.next();
					sidText.setText(rs.getString("ID"));
					snameText.setText(rs.getString("NAME"));
					ratingText.setText(rs.getString("RATING"));
					addressText.setText(rs.getString("address"));
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updateCompanyButton = new Button("Update Company");
		updateCompanyButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE company "
					+ "SET name='" + snameText.getText() + "', "
					+ "rating=" + ratingText.getText() + ", "
					+ "address ='"+ addressText.getText() + "' WHERE id = "
					+ companyIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					i = statement.executeUpdate("commit");
					
					loadCompanies();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		sidText = new TextField(15);
		sidText.setEditable(false);
		snameText = new TextField(15);
		ratingText = new TextField(15);
		addressText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Company ID:"));
		first.add(sidText);
		first.add(new Label("Name:"));
		first.add(snameText);
		first.add(new Label("Rating:"));
		first.add(ratingText);
		first.add(new Label("Address:"));
		first.add(addressText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateCompanyButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}


}
