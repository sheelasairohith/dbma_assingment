package person;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdatePerson extends Panel 
{
	Button updatePersonButton;
	List PersonIDList;
	TextField sidText, snameText, phone_noText, addressText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdatePerson() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","assingment","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	public void loadPersons() 
	{	   
		try 
		{
			PersonIDList.removeAll();
		  rs = statement.executeQuery("SELECT person_ID FROM person");
		  while (rs.next()) 
		  {
			PersonIDList.add(rs.getString("person_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    PersonIDList = new List(10);
		loadPersons();
		add(PersonIDList);
		
		PersonIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM person where PERSON_ID ="+PersonIDList.getSelectedItem());
					rs.next();
					sidText.setText(rs.getString("person_ID"));
					snameText.setText(rs.getString("NAME"));
					phone_noText.setText(rs.getString("phone_no"));
					addressText.setText(rs.getString("address"));
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		//Handle Update Sailor Button
		updatePersonButton = new Button("Update Person");
		updatePersonButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Person "
					+ "SET name='" + snameText.getText() + "', "
					+ "phone_no=" + phone_noText.getText() + ", "
					+ "address ='"+ addressText.getText() + "' WHERE person_id = "
					+ PersonIDList.getSelectedItem());
					errorText.append("\nUpdated " + i + " rows successfully");
					i = statement.executeUpdate("commit");
					
					loadPersons();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		sidText = new TextField(15);
		sidText.setEditable(false);
		snameText = new TextField(15);
		phone_noText = new TextField(15);
		addressText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Person ID:"));
		first.add(sidText);
		first.add(new Label("Name:"));
		first.add(snameText);
		first.add(new Label("Phone Number:"));
		first.add(phone_noText);
		first.add(new Label("Address:"));
		first.add(addressText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updatePersonButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}


}
