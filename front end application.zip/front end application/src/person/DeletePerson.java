package person;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeletePerson extends Panel 
{
	Button deletePersonButton;
	List PersonsIDList;
	TextField sidText, snameText, Phone_noText, addressText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeletePerson() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","assingment","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	public void loadPersons() 
	{	   
		try 
		{

			PersonsIDList.removeAll();
		  rs = statement.executeQuery("SELECT * FROM person");
		  while (rs.next()) 
		  {
			PersonsIDList.add(rs.getString("Person_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    PersonsIDList = new List(10);
		loadPersons();
		add(PersonsIDList);
		
		PersonsIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM person");
					while (rs.next()) 
					{
						if (rs.getString("person_ID").equals(PersonsIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						sidText.setText(rs.getString("Person_ID"));
						snameText.setText(rs.getString("NAME"));
						Phone_noText.setText(rs.getString("Phone_no"));
						addressText.setText(rs.getString("Address"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		deletePersonButton = new Button("Delete Person");
		deletePersonButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM person WHERE person_ID = "
							+ PersonsIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					sidText.setText(null);
					snameText.setText(null);
					Phone_noText.setText(null);
					addressText.setText(null);
					statement.executeUpdate("commit");
					loadPersons();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		sidText = new TextField(15);
		snameText = new TextField(15);
		Phone_noText = new TextField(15);
		addressText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(4, 2));
		first.add(new Label("Person ID:"));
		first.add(sidText);
		first.add(new Label("Name:"));
		first.add(snameText);
		first.add(new Label("Phone Number:"));
		first.add(Phone_noText);
		first.add(new Label("Address:"));
		first.add(addressText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deletePersonButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

}
