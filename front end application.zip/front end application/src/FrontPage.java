
import java.awt.*; 
import java.awt.event.*;

import javax.swing.*;
import javax.swing.JOptionPane; 
import company.*;
import person.AddPerson;
import person.DeletePerson;
import person.UpdatePerson;
import report.AddReport;
import report.DeleteReport;
import report.UpdateReport;
import scanner.AddScanner;
import scanner.DeleteScanner;
import scanner.UpdateScanner;
;class frontPage extends JFrame implements ActionListener
{ 
	  String msg = ""; 
	  Label ll;
	  CardLayout cardLO;
	  
	  //Create Panels for each of the menu items, welcome screen panel and home screen panel with CardLayout
	  AddCompany add;
	  UpdateCompany ups;
	  DeleteCompany dels;
	  AddPerson addP;
	  UpdatePerson upP;
	  DeletePerson delP;
	  AddScanner addS;
	  UpdateScanner upS;
	  DeleteScanner delS;
	  AddReport addR;
	  DeleteReport delR;
	  UpdateReport upR;
	  
	  Panel home,welcome; 
	  
	  public frontPage() 
	  { 
			cardLO = new CardLayout(); 
			
			//Create an empty home panel and set its layout to card layout 
			home = new Panel(); 
			home.setLayout(cardLO);  

			
			ll = new Label();
			ll.setAlignment(Label.CENTER);  
			ll.setText("Welcome to Retina based age classigication System database");
			
			//Create welcome panel and add the label to it
			welcome = new Panel();
			welcome.add(ll);		 
			
			//create panels for each of our menu items and build them with respective components
			add=new AddCompany();add.buildGUI();
			ups = new UpdateCompany();  ups.buildGUI();
			dels = new DeleteCompany();	dels.buildGUI();
			addP = new AddPerson();addP.buildGUI(); 
			upP = new UpdatePerson();upP.buildGUI();
			delP=new DeletePerson();delP.buildGUI();
			addS=new AddScanner();addS.buildGUI();
			upS=new UpdateScanner();upS.buildGUI();
			delS=new DeleteScanner();delS.buildGUI();
			addR=new AddReport();addR.buildGUI();
			delR=new DeleteReport();delR.buildGUI();
			upR=new UpdateReport();upR.buildGUI();
			//add all the panels to the home panel which has a cardlayout
			home.add(welcome, "Welcome"); 
			home.add(add, "Add Company"); 
			home.add(ups, "Update Company"); 
			home.add(dels, "Delete Company"); 
			home.add(addP, "Add Person");
			home.add(upP, "Update Person"); 
			home.add(delP,"Delete Person");
			home.add(addS,"Add Scanner");
			home.add(upS,"Update Scanner");
			home.add(delS,"Delete Scanner");
			home.add(addR,"Add Report");
			home.add(delR,"Delete Report");
			home.add(upR,"Update Report");
			// add home panel to main frame  
			add(home); 
		 
			// create menu bar and add it to frame 
			MenuBar mbar = new MenuBar(); 
			setMenuBar(mbar); 
		 
			// create the menu items and add it to Menu
			Menu Compnay = new Menu("Company "); 
			MenuItem item1, item2, item3; 
			Compnay.add(item1 = new MenuItem("Add Company")); 
			Compnay.add(item2 = new MenuItem("View Company")); 
			Compnay.add(item3 = new MenuItem("Delete Company")); 
			mbar.add(Compnay);  
		 
			Menu Scanner = new Menu("Scanner"); 
			MenuItem item4, item5, item6; 
			Scanner.add(item4 = new MenuItem("Add Scanner")); 
			Scanner.add(item5 = new MenuItem("View Scanners")); 
			Scanner.add(item6 = new MenuItem("Delete Scanner"));  
			mbar.add(Scanner); 
			
			Menu Person = new Menu("Person"); 
			MenuItem item7, item8, item9; 
			Person.add(item7 = new MenuItem("Add Person")); 
			Person.add(item8 = new MenuItem("View Persons")); 
			Person.add(item9 = new MenuItem("Delete Person")); 
			mbar.add(Person); 			

			Menu Report = new Menu("Report"); 
			MenuItem item10, item11, item12; 
			Report.add(item10 = new MenuItem("Add Report")); 
			Report.add(item11 = new MenuItem("View Report")); 
			Report.add(item12 = new MenuItem("Delete Report")); 
			mbar.add(Report); 			
			
			// register listeners
			item1.addActionListener(this); 
			item2.addActionListener(this); 
			item3.addActionListener(this); 
			item4.addActionListener(this); 
			item5.addActionListener(this); 
			item6.addActionListener(this); 
			item7.addActionListener(this); 
			item8.addActionListener(this); 
			item9.addActionListener(this); 
			item10.addActionListener(this); 
			item11.addActionListener(this); 
			item12.addActionListener(this); 
						
					
			 // Anonymous inner class which extends WindowAdaptor to handle the Window event: windowClosing  
			addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent we) 
				{ 
					quitApp();
				} 
			}); 
			
			//Frame properties
			setTitle("Retina Based Age Classification System"); 
			setSize(500, 600); 
			setVisible(true);	
			
	  }   
	  
	  public void actionPerformed(ActionEvent ae) 
	  { 
		  String arg = ae.getActionCommand(); 
		  if(arg.equals("Add Company"))
		  {
			cardLO.show(home, "Add Company"); 			
          }			
		 
		 else if(arg.equals("View Company")) 
		 {
			cardLO.show(home, "Update Company"); 
			ups.loadCompanies();
		 }
		 
		 else if(arg.equals("Delete Company")) 
		 {
			cardLO.show(home, "Delete Company"); 	
			dels.loadCompanies();
		 }
		 
		 else if(arg.equals("Add Person")) 
		 {
			cardLO.show(home, "Add Person"); 				
		 }
		 else if(arg.equals("View Persons")) 
		 {
			cardLO.show(home, "Update Person");
			upP.loadPersons();
		 }
		 else if(arg.equals("Delete Person")) 
		 {
			cardLO.show(home, "Delete Person");
			delP.loadPersons();
		 }
		 else if(arg.equals("Add Scanner")) 
		 {
			cardLO.show(home, "Add Scanner");
		 }
		 else if(arg.equals("View Scanners")) 
		 {
			cardLO.show(home, "Update Scanner");
			upS.loadScanners();
		 }
		 else if(arg.equals("Delete Scanner")) 
		 {
			cardLO.show(home, "Delete Scanner");
			delS.loadScanners();
		 }
		 else if(arg.equals("Add Report")) 
		 {
			cardLO.show(home, "Add Report");
		 }
		 else if(arg.equals("Delete Report")) 
		 {
			cardLO.show(home, "Delete Report");
			delR.loadReports(); 
		 }
		 else if(arg.equals("View Report")) 
		 {
			cardLO.show(home, "Update Report"); 
			upR.loadReports();
		 }
		
		
	  }
	  private void quitApp () {

			try {
				//Show a Confirmation Dialog.
			    	int reply = JOptionPane.showConfirmDialog (this,
						"Are you really want to exit\nFrom ReTina Scanner System?",
						"RetinaSystem - Exit", JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE);
				//Check the User Selection.
				if (reply == JOptionPane.YES_OPTION) {
					setVisible (false);	//Hide the Frame.
					dispose();            	//Free the System Resources.
					System.out.println ("Thanks for Using Retina based age classification System\nAuthor - sai rohith sheela");
					System.exit (0);        //Close the Application.
				}
				else if (reply == JOptionPane.NO_OPTION) {
					setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
				}
			} 

			catch (Exception e) {}

		}
	  public static void main(String ... args)
	  {
			new frontPage();	  
	  }
	  

} 
 

 
