package report;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class AddReport extends Panel
{
	Button AddReportButton;
	TextField sidText, scolourText, retina_ratioText, ageText, p_idText, s_idText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public AddReport()
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();

	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","assingment","vasavi");
		  statement = connection.createStatement();
		  statement.executeUpdate("commit");

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI() 
	{		
		//Handle Insert Account Button
		AddReportButton = new Button("Add Report");
		AddReportButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  String query= "INSERT INTO Report VALUES(" + sidText.getText() + ", " + "'" + scolourText.getText() + "'," + retina_ratioText.getText() + "," + ageText.getText() + ")";
				  int i = statement.executeUpdate(query);
				  statement.executeUpdate("commit");
				  query="insert into scan values("+ sidText.getText() + "," +p_idText.getText()+","+s_idText.getText()+")";
				  i=statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});
		sidText=new TextField(15);
		scolourText = new TextField(15);
		retina_ratioText = new TextField(15);
		ageText = new TextField(15);
		p_idText= new TextField(15);
		s_idText=new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 2));
		first.add(new Label("Report ID:"));
		first.add(sidText);
		first.add(new Label("Colour:"));
		first.add(scolourText);
		first.add(new Label("retina_ratio :"));
		first.add(retina_ratioText);
		first.add(new Label("Age:"));
		first.add(ageText);
		first.add(new Label("Person ID:"));
		first.add(p_idText);
		first.add(new Label("Scanner ID:"));
		first.add(s_idText);
		
		first.setBounds(125,80,200,140);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(AddReportButton);
        second.setBounds(125,220,150,100);         
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(125,320,300,200);
		
		setLayout(null);

		add(first);
		add(second);
		add(third);
		setSize(500, 600);
		setVisible(true);
		System.out.println("hello");
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

}
