package report;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteReport extends Panel 
{
	List ReportIDList;
	Button DeleteReportButton;
	TextField sidText, scolourText, retina_ratioText, ageText, p_idText, s_idText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteReport() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","assingment","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	public void loadReports() 
	{	   
		try 
		{

			ReportIDList.removeAll();
		  rs = statement.executeQuery("SELECT * FROM report");
		  while (rs.next()) 
		  {
			ReportIDList.add(rs.getString("r_ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    ReportIDList = new List(10);
	    System.out.println("hii");
		loadReports();
		add(ReportIDList);
		
		ReportIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM report where r_ID ="+ReportIDList.getSelectedItem());
					rs.next();
					sidText.setText(rs.getString("r_ID"));
					scolourText.setText(rs.getString("colour"));
					retina_ratioText.setText(rs.getString("Retina_ratio"));
					ageText.setText(rs.getString("Age"));
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
				try
				{
					rs = statement.executeQuery("SELECT * FROM scan where report_ID ="+ReportIDList.getSelectedItem());
					rs.next();
					System.out.println(rs);
					p_idText.setText(rs.getString("p_id"));
					s_idText.setText(rs.getString("s_id"));

				}
				catch(SQLException se)
				{
					p_idText.setText(null);
					s_idText.setText(null);
				}
			}
		});		
		
	    
		DeleteReportButton = new Button("Delete Report");
		DeleteReportButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM report WHERE r_ID = "
							+ ReportIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					sidText.setText(null);
					scolourText.setText(null);
					retina_ratioText.setText(null);
					ageText.setText(null);
					p_idText.setText(null);
					s_idText.setText(null);
					statement.executeUpdate("commit");
					loadReports();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		sidText = new TextField(15);
		scolourText = new TextField(15);
		retina_ratioText = new TextField(15);
		ageText = new TextField(15);
		p_idText=new TextField(15);
		s_idText=new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 2));
		first.add(new Label("Report ID:"));
		first.add(sidText);
		first.add(new Label("Colour:"));
		first.add(scolourText);
		first.add(new Label("Retina_ratio:"));
		first.add(retina_ratioText);
		first.add(new Label("Age:"));
		first.add(ageText);
		first.add(new Label("Person Id:"));
		first.add(p_idText);
		first.add(new Label("Scanner Id:"));
		first.add(s_idText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(DeleteReportButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

}
