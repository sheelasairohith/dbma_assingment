import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class Solution {
    static int c;
    static int isacceptable(int n,int[][] roads,int[] path)
    {
        for(int i=0;i<n;i++)
        {
            int k=path[i];
            int j=0;
            for(;j<n;j++)
            {
                if(roads[i][j]==1 && path[j]==k)
                    break;
                if(roads[j][i]==1 && path[j]==k)
                    break;
            }
            if(j==n)
                return 0;
        }
        return 1;
    }
    
    static void fun(int n,int[][] roads,int[] path,int i)
    {
        if(i==n)
        {
            if(isacceptable(n,roads,path)==1)
                c++;
            return;
        }
        path[i]=1;
        fun(n,roads,path,i+1);
        path[i]=2;
        fun(n,roads,path,i+1);
    }

    // Complete the kingdomDivision function below.
    static int kingdomDivision(int n, int[][] roads) {
        c=0;
        int[] path=new int[n];
        int[][] arr=new int[n][n];
        for(int i=0;i<n;i++)
        {
            path[i]=0;
            for(int j=0;j<n;j++)
                arr[i][j]=0;
        }
        for(int i=0;i<n-1;i++)
        {
            int a=roads[i][0];
            int b=roads[i][1];
            arr[a-1][b-1]=1;
            arr[b-1][a-1]=1;
        }
        fun(n,arr,path,0);
        return c;

    }

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws IOException {
       // BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));

        int n = scanner.nextInt();
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

        int[][] roads = new int[n-1][2];

        for (int i = 0; i < n-1; i++) {
            String[] roadsRowItems = scanner.nextLine().split(" ");
            scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

            for (int j = 0; j < 2; j++) {
                int roadsItem = Integer.parseInt(roadsRowItems[j]);
                roads[i][j] = roadsItem;
            }
        }

        int result = kingdomDivision(n, roads);

       // bufferedWriter.write(String.valueOf(result));
       // bufferedWriter.newLine();
        System.out.println(result);
       // bufferedWriter.close();

        scanner.close();
    }
}
