package scanner;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteScanner extends Panel 
{
	Button deleteScannerButton;
	List ScannerIDList;
	TextField sidText, snameText, costText, accuracyText, company_idText, dateText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteScanner() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","assingment","vasavi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	public void loadScanners() 
	{	   
		try 
		{

			ScannerIDList.removeAll();
		  rs = statement.executeQuery("SELECT * FROM retina_Scanner");
		  while (rs.next()) 
		  {
			ScannerIDList.add(rs.getString("ID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    ScannerIDList = new List(10);
	    System.out.println("hii");
		loadScanners();
		add(ScannerIDList);
		
		ScannerIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM retina_scanner where ID ="+ScannerIDList.getSelectedItem());
					rs.next();
					sidText.setText(rs.getString("ID"));
					snameText.setText(rs.getString("NAME"));
					costText.setText(rs.getString("Cost"));
					accuracyText.setText(rs.getString("Accuracy"));
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
				try
				{
					rs = statement.executeQuery("SELECT * FROM prepared_by where s_ID ="+ScannerIDList.getSelectedItem());
					rs.next();
					System.out.println(rs);
					company_idText.setText(rs.getString("c_id"));
					dateText.setText(rs.getString("day"));

				}
				catch(SQLException se)
				{
					company_idText.setText(null);
					dateText.setText(null);
				}
			}
		});		
		
	    
		deleteScannerButton = new Button("Delete Scanner");
		deleteScannerButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i=statement.executeUpdate("delete from prepared_by where s_id="+ScannerIDList.getSelectedItem());
					i = statement.executeUpdate("DELETE FROM Retina_Scanner WHERE ID = "
							+ ScannerIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					sidText.setText(null);
					snameText.setText(null);
					costText.setText(null);
					accuracyText.setText(null);
					company_idText.setText(null);
					dateText.setText(null);
					statement.executeUpdate("commit");
					loadScanners();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		sidText = new TextField(15);
		snameText = new TextField(15);
		costText = new TextField(15);
		accuracyText = new TextField(15);
		company_idText=new TextField(15);
		dateText=new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 2));
		first.add(new Label("Scanner ID:"));
		first.add(sidText);
		first.add(new Label("Name:"));
		first.add(snameText);
		first.add(new Label("cost:"));
		first.add(costText);
		first.add(new Label("Accuracy:"));
		first.add(accuracyText);
		first.add(new Label("Company Id:"));
		first.add(company_idText);
		first.add(new Label("date:"));
		first.add(dateText);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteScannerButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

}
